class WebApp extends ConsumerWidget {
  const WebApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return MaterialApp.router(
      title: 'Veg\'N Bio Web',
      theme: ThemeData(primarySwatch: Colors.green),
      routerConfig: webRouter, // routes spécifiques au Web
    );
  }
}