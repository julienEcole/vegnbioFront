class MobileApp extends ConsumerWidget {
  const MobileApp({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return MaterialApp.router(
      title: 'Veg\'N Bio Mobile',
      theme: ThemeData(primarySwatch: Colors.green),
      routerConfig: mobileRouter,
    );
  }
}