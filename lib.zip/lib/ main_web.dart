import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'config/app_config.dart';
import 'web_app.dart';

void main() async {
  await AppConfig.loadEnv();
  runApp(const ProviderScope(child: WebApp()));
}